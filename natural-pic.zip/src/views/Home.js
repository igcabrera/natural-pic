import Galeria from "../components/Galeria";

export default function Home() {
  return (
    <div id="Home">
      <h1>Natural Pic</h1>

      <Galeria />
    </div>
  );
}
